package mum.edu.cs544.ecommerce.eCommercedbservice.model;

public class Address {
}
