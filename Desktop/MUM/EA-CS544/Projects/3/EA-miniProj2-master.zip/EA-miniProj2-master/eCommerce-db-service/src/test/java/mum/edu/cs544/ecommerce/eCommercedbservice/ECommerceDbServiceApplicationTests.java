package mum.edu.cs544.ecommerce.eCommercedbservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ECommerceDbServiceApplicationTests {

    @Test
    void contextLoads() {
    }

}
