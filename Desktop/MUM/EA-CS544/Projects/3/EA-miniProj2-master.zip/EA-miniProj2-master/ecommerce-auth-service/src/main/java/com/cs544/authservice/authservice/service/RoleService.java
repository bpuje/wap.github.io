package com.cs544.authservice.authservice.service;

import com.cs544.authservice.authservice.model.Role;

public interface RoleService {
    public Role saveRole(Role role);
}
