package com.cs544.authservice.authservice.service;

import com.cs544.authservice.authservice.model.User;

public interface UserService {
    public User saveUser(User user);
}
