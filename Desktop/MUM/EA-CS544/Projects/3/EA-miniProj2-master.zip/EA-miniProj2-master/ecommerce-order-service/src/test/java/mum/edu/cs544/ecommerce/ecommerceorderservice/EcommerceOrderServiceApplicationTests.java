package mum.edu.cs544.ecommerce.ecommerceorderservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EcommerceOrderServiceApplicationTests {

    @Test
    void contextLoads() {
    }

}
