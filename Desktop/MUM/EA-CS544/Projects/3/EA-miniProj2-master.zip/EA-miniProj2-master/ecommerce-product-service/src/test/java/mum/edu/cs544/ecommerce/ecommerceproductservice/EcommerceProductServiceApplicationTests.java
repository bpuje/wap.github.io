package mum.edu.cs544.ecommerce.ecommerceproductservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EcommerceProductServiceApplicationTests {

    @Test
    void contextLoads() {
    }

}
