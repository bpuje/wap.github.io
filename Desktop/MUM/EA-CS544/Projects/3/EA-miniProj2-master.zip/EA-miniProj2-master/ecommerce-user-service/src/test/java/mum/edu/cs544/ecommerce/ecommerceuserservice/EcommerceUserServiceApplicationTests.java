package mum.edu.cs544.ecommerce.ecommerceuserservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EcommerceUserServiceApplicationTests {

    @Test
    void contextLoads() {
    }

}
