### Endpoints:

#### Products
- To get products list (catalog) `GET products-service/products/`
- To get product by id `GET products-service/products/{id}`
- To add product `POST products-service/products/`. Put data in body.
- To delete product by id `DELETE products-service/products/{id}`

