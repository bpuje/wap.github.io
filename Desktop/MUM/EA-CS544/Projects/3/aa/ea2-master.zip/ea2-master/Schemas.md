### Services


#### Localhost ports:
- auth_service `8081`
- products_service `8085`
- orders_service `8086`
- temp_users_service `8088`
- pays_service `8090`
- pays_cc_service `8091`
- pays_dc_service `8092`
- pays_pp_service `8093`
- ship_service `8095`
- stock_service `8096`
