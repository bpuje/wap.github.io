package edu.mum.ea2.auth_service;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;


@SpringBootApplication
public class Auth_serviceApplication {
	public static void main(String[] args) {
		SpringApplication.run(Auth_serviceApplication.class, args);
	}
}
