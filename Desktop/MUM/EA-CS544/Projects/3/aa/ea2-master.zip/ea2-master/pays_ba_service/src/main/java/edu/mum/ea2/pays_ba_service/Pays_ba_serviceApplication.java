package edu.mum.ea2.pays_ba_service;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;


@SpringBootApplication
public class Pays_ba_serviceApplication {
	public static void main(String[] args) {
		SpringApplication.run(Pays_ba_serviceApplication.class, args);
	}
}
