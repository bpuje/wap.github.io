package edu.mum.ea2.pays_cc_service;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;


@SpringBootApplication
public class Pays_cc_serviceApplication {
	public static void main(String[] args) {
		SpringApplication.run(Pays_cc_serviceApplication.class, args);
	}
}
