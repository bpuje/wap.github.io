package edu.mum.ea2.ship_service;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;


@SpringBootApplication
public class Ship_serviceApplication {
	public static void main(String[] args) {
		SpringApplication.run(Ship_serviceApplication.class, args);
	}
}
