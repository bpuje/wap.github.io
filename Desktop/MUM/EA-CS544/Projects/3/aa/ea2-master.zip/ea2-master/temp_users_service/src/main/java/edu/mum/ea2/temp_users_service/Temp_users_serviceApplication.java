package edu.mum.ea2.temp_users_service;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;


@SpringBootApplication
public class Temp_users_serviceApplication {
	public static void main(String[] args) {
		SpringApplication.run(Temp_users_serviceApplication.class, args);
	}
}
