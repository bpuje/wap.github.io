package mum.edu.cs544.student.springbatch1;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBatch1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
