package edu.mum.cs544.estore.prodservice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProdServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProdServiceApplication.class, args);
	}

}
