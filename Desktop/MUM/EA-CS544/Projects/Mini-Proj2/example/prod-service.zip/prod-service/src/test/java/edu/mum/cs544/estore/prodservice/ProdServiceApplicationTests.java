package edu.mum.cs544.estore.prodservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProdServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
