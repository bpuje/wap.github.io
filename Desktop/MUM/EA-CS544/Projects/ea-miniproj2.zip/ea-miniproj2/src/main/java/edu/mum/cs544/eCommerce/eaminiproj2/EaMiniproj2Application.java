package edu.mum.cs544.eCommerce.eaminiproj2;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EaMiniproj2Application {

	public static void main(String[] args) {
		SpringApplication.run(EaMiniproj2Application.class, args);
	}

}
