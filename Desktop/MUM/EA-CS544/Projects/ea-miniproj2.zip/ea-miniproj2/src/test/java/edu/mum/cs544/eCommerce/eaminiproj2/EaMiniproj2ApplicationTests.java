package edu.mum.cs544.eCommerce.eaminiproj2;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EaMiniproj2ApplicationTests {

	@Test
	void contextLoads() {
	}

}
